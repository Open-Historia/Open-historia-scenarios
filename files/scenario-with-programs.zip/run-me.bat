@echo off
echo pretend malware
